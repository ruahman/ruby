
# Both of these do the same thing, but the second form is preferred
users = Array.new
users = []
