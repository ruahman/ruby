
[1,2,3].count { |n| n.even? }
