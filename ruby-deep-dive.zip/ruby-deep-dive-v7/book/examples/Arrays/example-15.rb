
numbers = [3, 7, 12, 2, 49]
numbers.select { |n| n > 10 }
# => 12, 49
