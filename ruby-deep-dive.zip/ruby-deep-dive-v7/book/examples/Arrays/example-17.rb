
numbers = [1, 3, 3, 5, 5]
numbers = numbers.uniq
# => [1, 3, 5]
