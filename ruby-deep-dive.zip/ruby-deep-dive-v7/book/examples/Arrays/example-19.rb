
numbers.take(3)
numbers[0,3]
