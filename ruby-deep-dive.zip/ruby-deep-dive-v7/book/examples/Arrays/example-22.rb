
my_array = *a
# => "method called"

p my_array
# => [1,2,3,4,5]
