
users[0] # First element of the array
users[1] # Second element of the array
users[2] # Third element of the array
