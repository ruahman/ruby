
users.first # First element of the array
users.last  # Last element of the array
