
users.first(3) # First three elements of the array
users.last(3)  # Last three elements of the array
