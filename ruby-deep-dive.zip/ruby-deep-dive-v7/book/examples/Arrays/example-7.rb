
# Both of these have the same effect, << is prefered.
users.push "andrew"
users << "andrew"
