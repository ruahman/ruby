
users.unshift "robert"  # Adds an element in front of the array
users.shift             # Removes the first element of the array and returns it
