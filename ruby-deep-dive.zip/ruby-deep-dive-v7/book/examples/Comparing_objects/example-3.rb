
class BasicObject
  def ==(other)
    object_id == other.object_id
  end
end
