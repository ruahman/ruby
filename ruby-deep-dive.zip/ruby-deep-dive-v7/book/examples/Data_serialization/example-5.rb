
File.write("books.yml", serialized_book)
