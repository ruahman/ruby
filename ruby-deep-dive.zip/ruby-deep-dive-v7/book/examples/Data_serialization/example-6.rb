
File.write("books.yml", eloquent.to_yaml)
