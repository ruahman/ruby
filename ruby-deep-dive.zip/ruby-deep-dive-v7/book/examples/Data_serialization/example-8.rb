
require 'json'

hash = {
  water: 500,
  oil: 100
}

p hash.to_json
