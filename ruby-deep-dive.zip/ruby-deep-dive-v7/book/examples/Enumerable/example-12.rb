
library = Library.new
library.map(&:title)
