
enum.next
# StopIteration: iteration reached an end
