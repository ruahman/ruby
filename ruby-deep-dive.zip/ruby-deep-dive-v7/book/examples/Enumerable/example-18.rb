
loop { puts enum.next }
