
words = %w(cat dog cow)
p words.all? { |word| word.length == 3 }
