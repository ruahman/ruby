
These are the steps you need:

1. Create a new array
2. Iterate over the data using each
3. Call yield to process every element (which gives you the modified element)
4. Save the output from yield into the results array
5. Return the results
