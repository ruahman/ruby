
h = {}
h.fetch(:invalid, 'default')
# 'default'
