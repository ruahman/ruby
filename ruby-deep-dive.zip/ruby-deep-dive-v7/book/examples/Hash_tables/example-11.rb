
h = { name: 'Jose', age: 29 }
h.merge(age: 30, city: 'Spain')
# => { name: 'Jose', age: 30, city: 'Spain' }
