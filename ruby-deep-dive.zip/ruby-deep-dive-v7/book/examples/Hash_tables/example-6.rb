
h = Hash.new([])
h[:foo] << 5
h[:bar] << 10

h[:foo]
# [5,10]
