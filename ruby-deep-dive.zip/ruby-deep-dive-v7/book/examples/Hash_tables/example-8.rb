
h = {}
h[:invalid_key]
# nil
