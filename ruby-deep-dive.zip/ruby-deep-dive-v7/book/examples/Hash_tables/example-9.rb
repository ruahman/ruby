
h = {}
h.fetch(:invalid_key)
# KeyError: key not found: :invalid_key
