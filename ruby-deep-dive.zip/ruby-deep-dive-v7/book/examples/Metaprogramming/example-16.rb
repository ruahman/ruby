
eval "puts 5 + 5"
