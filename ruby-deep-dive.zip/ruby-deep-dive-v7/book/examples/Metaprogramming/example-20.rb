
describe Animal
  it 'must have a name' do
    expect(animal.name).to eq "Garfield"
  end
end
