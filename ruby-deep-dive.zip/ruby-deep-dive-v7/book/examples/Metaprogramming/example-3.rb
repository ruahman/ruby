
pt = PrivateTesting.new
pt.internal_method
NoMethodError: private method `internal_method' called for #<PrivateTesting:0x41c8050>
