
puts "method call"
self.puts "method call"
# NoMethodError: private method `puts' called for main:Object
