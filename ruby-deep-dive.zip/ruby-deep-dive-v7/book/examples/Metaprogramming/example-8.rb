
String.instance_methods(false).size
# 111
