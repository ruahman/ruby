
String.private_instance_methods(false).size
# 2
