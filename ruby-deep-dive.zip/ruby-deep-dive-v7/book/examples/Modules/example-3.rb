
module Numbers
  def self.double(number)
    number * 2
  end
end

puts Numbers.double(30)
