
Store.singleton_class.instance_eval { include(ClassMethods) }
