
my_lambda = -> { puts "Lambda called" }

my_lambda.call
my_lambda.()
my_lambda[]
