
things = ["cat", "dog"]
things.map(&:upcase)
