
Proc.new { |word| word.upcase }
