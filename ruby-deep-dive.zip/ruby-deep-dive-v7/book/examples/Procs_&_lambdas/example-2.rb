
# Form 2: recommended for multi-line blocks
[1, 2, 3].each do |num|
  puts num
end
