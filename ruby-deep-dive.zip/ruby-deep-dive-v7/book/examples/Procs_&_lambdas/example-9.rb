
say_something = -> { puts "This is a lambda" }
say_something.call
