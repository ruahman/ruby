
p "cat" =~ /a/
