
# Find the word 'like'
"Do you like cats?" =~ /like/
