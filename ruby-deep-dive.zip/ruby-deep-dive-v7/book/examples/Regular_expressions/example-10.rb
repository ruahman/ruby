
"regex are great".gsub(/(\w+)/, '-\1-')
