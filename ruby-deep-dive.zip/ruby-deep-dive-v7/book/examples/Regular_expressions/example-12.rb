
"this is some string".scan(/\w+/)
# => ["this", "is", "some", "string"]
