
"ascii".chars.map(&:ord)
# => [97, 115, 99, 105, 105]
