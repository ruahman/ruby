
str_1 = "cat".freeze
str_2 = "cat".freeze

str_1.object_id == str_2.object_id # true
