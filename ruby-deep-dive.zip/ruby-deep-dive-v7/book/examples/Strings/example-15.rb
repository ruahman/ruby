
animals = ["dog", "cat"].freeze
animals[0].replace("cat")

p animals
# Output: ["cat", "cat"]
