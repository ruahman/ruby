
"My friend really likes dogs".gsub("dogs", "cats")
