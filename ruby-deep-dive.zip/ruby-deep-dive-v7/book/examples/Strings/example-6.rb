
str = "ABCD-123"

puts str.split("-")
# => ["ABCD", "123"]
