
"hello there"[0..4]
# "hello"

"hello there"[1..-1]
# "ello there"
