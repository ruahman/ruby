
"Ruby is cool".each_char { |ch| puts ch }
