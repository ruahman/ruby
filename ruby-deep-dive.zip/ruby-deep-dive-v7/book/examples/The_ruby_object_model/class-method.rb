
p [].class
p "".class
p 30.class
