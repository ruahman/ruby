
ages = [18, 22, 25, 30]
ages.class
# => Array

20.class
# => Fixnum
