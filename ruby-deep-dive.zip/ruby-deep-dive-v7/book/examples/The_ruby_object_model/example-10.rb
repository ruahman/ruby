
class Animal
  class << self
    def speak
    end

    def run
    end

    def eat
    end
  end
end

p Animal.singleton_methods
