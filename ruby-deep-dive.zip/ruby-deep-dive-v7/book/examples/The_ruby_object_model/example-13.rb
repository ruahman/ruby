
module Foo
  X = 10

  class Bar
    puts X
  end
end
