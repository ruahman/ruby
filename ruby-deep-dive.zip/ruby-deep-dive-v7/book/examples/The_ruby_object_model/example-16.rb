
class Fixnum
  def +(other)
    "No addition for you!"
  end
end

puts 1 + 1
