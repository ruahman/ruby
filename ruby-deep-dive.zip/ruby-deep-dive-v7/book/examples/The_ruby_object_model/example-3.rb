
Person = Class.new
john   = Person.new

# <Person:0x429b010>
