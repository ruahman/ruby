
Array.included_modules
# [Enumerable, Kernel]

Array.ancestors - Array.included_modules
# [Array, Object, BasicObject]
