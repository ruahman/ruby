
str = "test"

def str.show
  puts self
end

p str.singleton_class
p str.singleton_methods
