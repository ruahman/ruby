
class Object < BasicObject
  include Kernel
end
