
at_exit do
  puts "Program finished at #{Time.now}"
end
