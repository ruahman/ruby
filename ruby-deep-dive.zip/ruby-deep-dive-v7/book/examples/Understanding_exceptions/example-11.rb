
class InvalidAnswer < StandardError
end

raise InvalidAnswer, "my error message"
