
class SandwichMaker
  def make_me_a_sandwich
  end
end

make = SandwichMaker.new
make.make_me_a_sandich

# NoMethodError: undefined method `make_me_a_sandich' for #<SandwichMaker:0x41cc5b0>
