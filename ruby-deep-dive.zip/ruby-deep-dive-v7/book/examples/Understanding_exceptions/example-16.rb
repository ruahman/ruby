
def log_message(msg, destination = $stdout)
  destination.write(msg + "\n")
end
