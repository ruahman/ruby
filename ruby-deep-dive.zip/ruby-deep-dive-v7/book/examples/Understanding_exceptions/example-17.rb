
"This is a string" + 1
# TypeError: can't convert Fixnum into String
