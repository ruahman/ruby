
animal = Cat.new
# NameError: uninitialized constant Cat
