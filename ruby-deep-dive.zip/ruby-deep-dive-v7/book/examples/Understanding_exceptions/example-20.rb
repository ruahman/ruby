
class Cat
end

animal = Cat.new
