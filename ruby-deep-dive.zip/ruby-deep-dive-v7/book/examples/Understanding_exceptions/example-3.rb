
File.open("random_file_001.txt")
