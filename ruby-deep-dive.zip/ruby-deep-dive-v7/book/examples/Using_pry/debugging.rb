
def get_number
  numbers = [10, 20, 30]
  numbers[2]
end

get_number * 10
