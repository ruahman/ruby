
post '/create_user' do
  "User #{params[:name]} created!"
end
